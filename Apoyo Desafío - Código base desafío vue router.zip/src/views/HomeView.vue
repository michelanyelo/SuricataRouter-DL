<template>
  <Card />
</template>

<script>
// @ is an alias to /src
import Card from '../components/Card.vue'

export default {
  components: {
    Card
  }
}
</script>
